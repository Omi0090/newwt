const express = require('express');
const mysql = require('mysql2/promise');
const path = require('path');

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// MySQL connection config
const dbConfig = {
  host: 'localhost',
  user: 'root',
  password: 'mysqlom',
  database: 'library_db2',
};

// Add a new book
app.post('/api/books2', async (req, res) => {
  const { title, author, isbn, publication_year } = req.body;
  if (!title || !author || !isbn || !publication_year) {
    return res.status(400).json({ error: 'All fields required' });
  }

  try {
    const con = await mysql.createConnection(dbConfig);
    const [result] = await con.execute(
      'INSERT INTO books2 (title, author, isbn, publication_year) VALUES (?, ?, ?, ?)',
      [title, author, isbn, publication_year]
    );
    await con.end();
    res.json({ message: 'Book added', id: result.insertId });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get all books
app.get('/api/books2', async (req, res) => {
  try {
    const con = await mysql.createConnection(dbConfig);
    const [rows] = await con.execute('SELECT * FROM books2');
    await con.end();
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Delete book by ID
app.delete('/api/books2/:id', async (req, res) => {
  const bookId = req.params.id;
  try {
    const con = await mysql.createConnection(dbConfig);
    const [result] = await con.execute('DELETE FROM books2 WHERE id = ?', [bookId]);
    await con.end();
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Book not found' });
    }
    res.json({ message: 'Book deleted' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update book by ISBN
app.put('/api/books2/isbn/:isbn', async (req, res) => {
  const { isbn } = req.params;
  const { title, author, publication_year } = req.body;

  try {
    const con = await mysql.createConnection(dbConfig);
    const [result] = await con.execute(
      'UPDATE books2 SET title = ?, author = ?, publication_year = ? WHERE isbn = ?',
      [title, author, publication_year, isbn]
    );
    await con.end();

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Book not found' });
    }

    res.json({ message: 'Book updated' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Start server
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
