const express = require('express');
const mysql = require('mysql2/promise');

const path = require('path');

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// MySQL connection config
const dbConfig = {
  host: 'localhost',
  user: 'root',
  password: 'mysqlom',
  database: 'library_db2',
};

// API: Add new book
app.post('/api/books2', async (req, res) => {
  const { title, author, isbn, publication_year } = req.body;
  if (!title || !author || !isbn || !publication_year) {
    return res.status(400).json({ error: 'All fields required' });
  }

  try {
    const con = await mysql.createConnection(dbConfig);
    const [result] = await con.execute(
      'INSERT INTO books2 (title, author, isbn, publication_year) VALUES (?, ?, ?, ?)',
      [title, author, isbn, publication_year]
    );
    await con.end();
    res.json({ message: 'Book added', id: result.insertId });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// API: Get all books
app.get('/api/books2', async (req, res) => {
  try {
    const con = await mysql.createConnection(dbConfig);
    const [rows] = await con.execute('SELECT * FROM books2');
    await con.end();
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// API: Delete book by ID
app.delete('/api/books2/:id', async (req, res) => {
  const bookId = req.params.id;
  try {
    const con = await mysql.createConnection(dbConfig);
    const [result] = await con.execute('DELETE FROM books2 WHERE id = ?', [bookId]);
    await con.end();
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Book not found' });
    }
    res.json({ message: 'Book deleted' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Start server
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});




// -- Create the database
// CREATE DATABASE IF NOT EXISTS library_db2;

// -- Use the database
// USE library_db2;

// -- Create the table with all necessary columns
// CREATE TABLE IF NOT EXISTS books2 (
//     id INT AUTO_INCREMENT PRIMARY KEY,
//     title VARCHAR(255) NOT NULL,
//     author VARCHAR(255) NOT NULL,
//     isbn VARCHAR(50) NOT NULL,
//     publication_year INT NOT NULL
// );
// select * FROM books2;
// -- Ensure the MySQL root user is configured correctly
// ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'mysqlom';
// FLUSH PRIVILEGES;
