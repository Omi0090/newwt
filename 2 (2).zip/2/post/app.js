const express = require('express');
const path = require('path');
const db = require('./db');

const app = express();
const PORT = 3000;

// Middleware to parse URL-encoded form data
app.use(express.urlencoded({ extended: false }));

// Serve the form
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, './index.html'));
});

// Handle POST form submission
app.post('/submit', (req, res) => {
  const { name, email } = req.body;

  if (!name || !email) {
    return res.send('Name and email are required.');
  }

  const sql = 'INSERT INTO students (name, email) VALUES (?, ?)';
  db.query(sql, [name, email], (err, result) => {
    if (err) throw err;
    res.send(`Student ${name} inserted successfully!`);
  });
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
