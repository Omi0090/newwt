const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const PORT = 3000;

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Hardcoded credentials
const validUser = {
  userid: "admin",
  password: "1234"
};

// Routes
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

app.post('/login', (req, res) => {
  const { userid, password } = req.body;

  if (userid === validUser.userid && password === validUser.password) {
    res.send(`<h3 style="color:green;">Login successful. Welcome, ${userid}!</h3>`);
  } else {
    res.send(`<h3>Invalid credentials. Please <a href="/">try again</a>.</h3>`);
  }
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
