package com.example.student;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class StudentServlet extends HttpServlet {
    public void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String rollno = request.getParameter("rollno");
        String fname = request.getParameter("fname");
        String lname = request.getParameter("lname");
        String year = request.getParameter("year");
        String gender = request.getParameter("gender");

        
        String[] qualifications = request.getParameterValues("qualification");
        String qualification = String.join(",", qualifications);

        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Connect to MySQL
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/studentdb", "root", "passNhiMilega");

            
            PreparedStatement ps1 = con.prepareStatement("SELECT * FROM student11 WHERE rollno = ?");
            ps1.setString(1, rollno);
            ResultSet rs = ps1.executeQuery();

            if (rs.next()) {
                out.println("<h3>This student is already registered.</h3>");
            } else {
                PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO student11 (rollno, fname, lname, year, gender, qualification) VALUES (?, ?, ?, ?, ?, ?)");
                ps.setString(1, rollno);
                ps.setString(2, fname);
                ps.setString(3, lname);
                ps.setString(4, year);
                ps.setString(5, gender);
                ps.setString(6, qualification);

                ps.executeUpdate();
                out.println("<h3>Successfully Registered!</h3>");
            }

            con.close();
        } catch (Exception e) {
            out.println("<h3>Error: " + e.getMessage() + "</h3>");
        }
    }
}
