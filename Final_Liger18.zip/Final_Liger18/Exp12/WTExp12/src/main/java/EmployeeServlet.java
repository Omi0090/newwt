import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class EmployeeServlet extends HttpServlet {
    private static final long serialVersionUID = 1L; // Add this line to avoid the warning

    
    private static final String URL = "jdbc:mysql://localhost:3306/WTExp";
    private static final String USER = "root";
    private static final String PASSWORD = "Mayur#05"; // Replace with your MySQL password

   
    private static Connection connection = null;

    public void init() {
        try {
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String firstName = request.getParameter("first_name");

        if (firstName == null || firstName.isEmpty()) {
            displayAllEmployees(out);
        } else {
            displayEmployeeByFirstName(firstName, out);
        }
    }

    private void displayAllEmployees(PrintWriter out) {
        try {
            String query = "SELECT * FROM employees";
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            out.println("<html><body>");
            out.println("<h2>Employee Information</h2>");
            out.println("<table border='1'><tr><th>Emp ID</th><th>First Name</th><th>Last Name</th><th>Department</th><th>Salary</th></tr>");

            while (rs.next()) {
                out.println("<tr><td>" + rs.getInt("emp_id") + "</td>");
                out.println("<td>" + rs.getString("first_name") + "</td>");
                out.println("<td>" + rs.getString("last_name") + "</td>");
                out.println("<td>" + rs.getString("department") + "</td>");
                out.println("<td>" + rs.getDouble("salary") + "</td></tr>");
            }

            out.println("</table>");
            out.println("<br><br>");
            out.println("<form action='EmployeeServlet' method='get'>");
            out.println("Search by First Name: <input type='text' name='first_name' />");
            out.println("<input type='submit' value='Search' />");
            out.println("</form>");
            out.println("</body></html>");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void displayEmployeeByFirstName(String firstName, PrintWriter out) {
        try {
            String query = "SELECT * FROM employees WHERE first_name = ?";
            PreparedStatement stmt = connection.prepareStatement(query);
            stmt.setString(1, firstName);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                out.println("<html><body>");
                out.println("<h2>Employee Information for " + firstName + "</h2>");
                out.println("<table border='1'><tr><th>Emp ID</th><th>First Name</th><th>Last Name</th><th>Department</th><th>Salary</th></tr>");
                out.println("<tr><td>" + rs.getInt("emp_id") + "</td>");
                out.println("<td>" + rs.getString("first_name") + "</td>");
                out.println("<td>" + rs.getString("last_name") + "</td>");
                out.println("<td>" + rs.getString("department") + "</td>");
                out.println("<td>" + rs.getDouble("salary") + "</td></tr>");
                out.println("</table>");
            } else {
                out.println("<html><body><h3>Data not found for the given first name.</h3></body></html>");
            }

            out.println("<br><br>");
            out.println("<form action='EmployeeServlet' method='get'>");
            out.println("Search by First Name: <input type='text' name='first_name' />");
            out.println("<input type='submit' value='Search' />");
            out.println("</form>");
            out.println("</body></html>");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void destroy() {
        try {
            if (connection != null) {
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
