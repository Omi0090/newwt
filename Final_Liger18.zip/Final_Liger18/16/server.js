const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const app = express();

// Middleware to parse JSON request bodies
app.use(bodyParser.json());

// Serve static files (HTML, CSS, JS)
app.use(express.static(path.join(__dirname, 'public')));

let books = []; // Store books in-memory (for simplicity)

// Add a new book
app.post('/books', (req, res) => {
    const { title, author, ISBN, publicationYear } = req.body;

    // Simple validation
    if (!title || !author || !ISBN || !publicationYear) {
        return res.status(400).send('Missing required book details');
    }

    // Create a new book object and add to books array
    const newBook = { title, author, ISBN, publicationYear };
    books.push(newBook);
    res.status(201).json(newBook);
});

// Get a specific book by ISBN
app.get('/books/:isbn', (req, res) => {
    const { isbn } = req.params;

    // Find the book with the given ISBN
    const book = books.find(b => b.ISBN === isbn);

    if (!book) {
        return res.status(404).send('Book not found');
    }

    res.status(200).json(book);
});

// Update an existing book by ISBN
app.put('/books/:isbn', (req, res) => {
    const { isbn } = req.params;
    const { title, author, publicationYear } = req.body;

    // Find the book with the given ISBN
    const book = books.find(b => b.ISBN === isbn);

    if (!book) {
        return res.status(404).send('Book not found');
    }

    // Update book details
    if (title) book.title = title;
    if (author) book.author = author;
    if (publicationYear) book.publicationYear = publicationYear;

    res.status(200).json(book);
});

// Start the server
app.listen(3000, () => {
    console.log('Server is running on http://localhost:3000');
});
