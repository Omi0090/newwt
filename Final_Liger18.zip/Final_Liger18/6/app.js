const express = require('express');
const bodyParser = require('body-parser');
const db = require('./db');
const path = require('path');

const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'index.html')));


app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});


// Get student info
app.post('/get-student', (req, res) => {
  const studentId = req.body.studentId;
  db.query('SELECT * FROM users6 WHERE id = ?', [studentId], (err, results) => {
    if (err) throw err;
    if (results.length > 0) {
      res.send(`<h2>Student Info</h2><p>ID: ${results[0].id}</p><p>Name: ${results[0].name}</p><p>Age: ${results[0].age}</p>`);
    } else {
      res.send('<p>No student found with that ID.</p>');
    }
  });
});

// Delete student info
app.post('/delete-student', (req, res) => {
  const studentId = req.body.studentId;
  db.query('DELETE FROM users6 WHERE id = ?', [studentId], (err, results) => {
    if (err) throw err;
    if (results.affectedRows > 0) {
      res.send('<p>Student record deleted successfully.</p>');
    } else {
      res.send('<p>No student found to delete.</p>');
    }
  });
});

app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
