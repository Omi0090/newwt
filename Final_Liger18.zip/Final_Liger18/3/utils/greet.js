function sayHello(name) {
    return `Hello, ${name}!`;
}

module.exports = {
    sayHello
};
