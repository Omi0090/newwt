function add(a, b) {
    return a + b;
}

function subtract(a, b) {
    return a - b;
}

const PI = 3.14159;

module.exports = {  // Exporting functions
    add,
    subtract,
    PI
};
