const maths = require('./maths'); // Importing from same directory
const greet = require('./utils/greet'); // Importing from diff directory

console.log("Addition:", maths.add(20, 10));
console.log("Subtraction:", maths.subtract(20, 10));
console.log("Value of PI:", maths.PI);


console.log(greet.sayHello("Mayur"));
