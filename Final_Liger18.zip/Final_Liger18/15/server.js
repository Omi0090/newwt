const express = require("express");
const app = express();
const path = require("path");


app.use(express.json());
app.use(express.urlencoded({ extended: true })); 

let books = [];  


app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "index.html")); 
});


app.post("/books", (req, res) => {
    const { title, author, ISBN, publicationYear } = req.body;

    
    if (!title || !author || !ISBN || !publicationYear) {
        return res.status(400).send("Missing required book details");
    }

    
    const newBook = { title, author, ISBN, publicationYear };
    books.push(newBook);

    res.status(201).json(newBook);
});


app.get("/books", (req, res) => {
    res.status(200).json(books);
});


app.delete("/books/:isbn", (req, res) => {
    const { isbn } = req.params;

    
    const bookIndex = books.findIndex(book => book.ISBN === isbn);

    if (bookIndex === -1) {
        return res.status(404).send("Book not found");
    }

  
    books.splice(bookIndex, 1);
    res.status(200).send("Book deleted successfully");
});


app.listen(3000, () => {
    console.log("Server running on http://localhost:3000/");
});
