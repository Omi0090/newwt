const express = require("express");
const mysql = require("mysql");
const path = require("path");

const bodyParser = require("body-parser");

const app = express();


app.use(bodyParser.urlencoded({ extended: true }));


app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "index.html"));
});

// MySQL connection
const db = mysql.createConnection({
  host: "localhost",
  user: "root", 
  password: "Mayur#05", 
  database: "studentdbExp5"
});

db.connect((err) => {
  if (err) throw err;
  console.log("Connected to MySQL!");
});


// Handle form submission
app.post("/", (req, res) => {
  const { name, email, age } = req.body;

  const query = "INSERT INTO users1 (name, email, age) VALUES (?, ?, ?)";
  db.query(query, [name, email, age], (err, result) => {
    if (err) throw err;
    res.send("<h2>Student information inserted successfully!</h2><br><a href='/'>Back</a>");

  });
});


// Start server
app.listen(3000, () => {
  console.log("Server running at http://localhost:3000");
});
