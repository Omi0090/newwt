const express = require("express");
const app = express();

const path = require("path");

app.use(express.urlencoded({ extended: true }));

// Hardcoded credentials
const validUser = "Liger_18";
const validPass = "1234";


app.get("/", (req, res) => {


    res.sendFile(path.join(__dirname, "login.html"));
});


app.post("/", (req, res) => {

    const userName = req.body.name;
    const pass = req.body.pass;


    if (userName === validUser && pass === validPass) {
        res.send("<h2>Login Successful!</h2>");
    } else {
        res.send("<h2>Invalid credentials. Please try again.</h2><br><a href='/'>Back to Login</a>");
    }
});



app.listen(3000, () => {
    console.log("Server running on http://localhost:3000/");
});
