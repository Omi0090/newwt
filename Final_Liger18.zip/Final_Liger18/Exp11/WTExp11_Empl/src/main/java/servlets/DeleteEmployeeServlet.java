package servlets;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class DeleteEmployeeServlet extends HttpServlet {
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int empId = Integer.parseInt(request.getParameter("emp_id"));

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        try {
            // Load JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/WTExp", "root", "apnaPassDalo#Liger_18"); 

            // Check if employee exists
            PreparedStatement checkStmt = conn.prepareStatement("SELECT * FROM employee WHERE emp_id = ?");
            checkStmt.setInt(1, empId);
            ResultSet rs = checkStmt.executeQuery();

            if (rs.next()) {
                PreparedStatement deleteStmt = conn.prepareStatement("DELETE FROM employee WHERE emp_id = ?");
                deleteStmt.setInt(1, empId);
                deleteStmt.executeUpdate();
                out.println("<h3>Employee ID " + empId + " deleted successfully.</h3>");
            } else {
                out.println("<h3>Data not found for Employee ID: " + empId + "</h3>");
            }

            conn.close();

        } catch (Exception e) {
            out.println("<h3>Error: " + e.getMessage() + "</h3>");
        }
    }
}
